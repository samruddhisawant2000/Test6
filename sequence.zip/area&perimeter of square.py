l=int (input("enter side of square"))
Area=l*l
perimeter=4*l
print("Area of square=",Area)
print("perimeter of square=",perimeter)
