l=int(input("enter length of rectangle"))
b=int(input("enter length of rectangle"))
Area=l*b
perimeter=2*(l+b)
print("Area of rectangle=",Area)
print("perimeter of rectangle=",perimeter)
