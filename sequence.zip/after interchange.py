a=int(input("enter 1st no:"))
b=int(input("enter 2nd no:"))
print("before interchange a={0} b={1}".format(a,b))
c=a
a=b
b=c
print("after interchange a={0} b={1}".format(a,b))

