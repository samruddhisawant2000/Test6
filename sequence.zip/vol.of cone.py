r=int(input(" Enter radius "))
l=int(input(" Enter length"))
pi=3.14
v=pi*r*l
print("volume of cone=",v)
