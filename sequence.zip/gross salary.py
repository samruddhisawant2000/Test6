a=int(input("enter basic salary"))
da=a*12/100
hra=a*10/100

gross=da+hra+a
print("gross salary=",gross)
