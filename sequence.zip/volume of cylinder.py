r=int(input("entre radius of cylinder"))
h=int(input("enter height of cylinder"))
Pi=3.14
Vc=Pi*r*r*h
print("volume of cylinder=",Vc)
