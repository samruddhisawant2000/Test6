a=(input("enter first name"))
b=(input("enter middle name"))
c=(input("enter last name"))
print("full name=",a,"",b,"",c)
   
