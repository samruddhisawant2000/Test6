a=int(input("enter 1st no:"))
b=int(input("enter 2nd no:"))
if a>b:
    print("a is greater than b")

    else:
    print("a is not greater than b")
    print("largest no=",a)
    print(a,"is greater than",b)
    print("{0}is greater than {1}".format(a,b))
