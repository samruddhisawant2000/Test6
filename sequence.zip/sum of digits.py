n=int(input("enter a two digit no:"))
a=n%10
b=n//10
sum=a+b
print("sum of digits=",sum)
