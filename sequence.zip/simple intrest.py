P=int(input("entre principle amount"))
N=int(input("entre no.of year"))
R=int(input("entre rate of intrest"))
Si=P*N*R/100
print("Simple intrest=",Si)
