a=int(input("enter 1st no:"))
b=int(input("enter 2nd no:"))
c=int(input("enter 3rd no:"))
d=int(input("enter 4th no:"))

Total=a+b+c+d
Average=Total/4
print("Average=",Average)
      
