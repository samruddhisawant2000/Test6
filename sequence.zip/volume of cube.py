a=int(input("enter edge of the cube"))
Vc=a*a*a
print("volume of cube=",Vc)
