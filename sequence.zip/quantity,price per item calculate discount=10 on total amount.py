a=int(input("entre quantity of item"))
b=int(input("entre price per item"))

total=a*b
discount=total*10/100
totalamount=total-discount
print("total amount=",totalamount)
