a=int(input("enter any no in km"))
m=a*1000
print("km convert into meter=",m)
