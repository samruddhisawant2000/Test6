r=int(input("entre radius"))
Pi=3.14
Vs=4/3*Pi*r*r*r
print("volume of sphere=",Vs)
